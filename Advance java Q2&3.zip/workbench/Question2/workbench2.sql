use productdb;
CREATE TABLE product (
prod_id varchar(30),
prod_name varchar(40),
prod_price int(15)
);
select * from product;